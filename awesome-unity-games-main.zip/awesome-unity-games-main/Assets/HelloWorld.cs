using UnityEngine;
public class HelloWorld : MonoBehaviour {
    void Start() {
        //Sends a hello message.
        Debug.Log("Hello World!");
    }
}
